# The Coalition of the Lost — New Recruit / Warhammer 40,000 11th Edition

Unofficial fan-made catalogue add-on for **New Recruit**, using the current BSData/New Recruit 11th-edition catalogue format.

## Files
- `The Coalition of the Lost.json` — faction catalogue.

## Install from GitHub
1. Create a **public** GitHub repository (for example `coalition-of-the-lost-11e`).
2. Upload `The Coalition of the Lost.json` to the repository root and commit it to the default branch.
3. In New Recruit, open **My Systems** and choose **Add from GitHub** (wording may vary by app version).
4. Enter the repository owner/name and select the catalogue when prompted. If the app asks for a catalogue file, choose `The Coalition of the Lost.json`.
5. Refresh/reload the game data, then create a roster using the Warhammer 40,000 11th Edition system and select **The Coalition of the Lost**.

## Important playtest status
This is a **community fan add-on**, not official Games Workshop or BSData content. All unit profiles, points, abilities and detachment rules in this starter catalogue are provisional playtest values created for this add-on. They are not official points or official datasheets. Check every value against your group's agreed playtest document before a game.

The catalogue is deliberately conservative about automation: New Recruit can display and cost catalogue entries, but a custom catalogue may not enforce all 11th Edition detachment-point caps, Force Dispositions, cross-detachment restrictions, or every conditional rule. Check the official current rules and record DP/dispositions separately if the app does not enforce them.

## Current contents
- 2 Primarch-level characters: Aurelian Voss and Enoch Sareth
- 4 supporting characters
- 5 infantry formations
- 3 vehicles
- 1 three-DP core detachment: The Unbound Conclave
- 6 one-DP specialist detachments

## Technical basis
The file follows the JSON BattleScribe catalogue envelope and identifiers used by the current `BSData/wh40k-11e` repository. It is intended to be added as a separate catalogue, not to replace or fork the official 11th-edition game system.

## Disclaimer
Warhammer 40,000 and New Recruit are trademarks/names belonging to their respective owners. This is an unofficial, non-commercial fan project. No affiliation with or endorsement by Games Workshop, BSData, or New Recruit is implied. Do not redistribute official rulebook text or official artwork.
